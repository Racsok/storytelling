# El Partidazo al Lado de las Calles

La claridad del amanecer pintaba sus rayos dorados en el horizonte, mientras Oscar Gacha se desperezaba. Con su abrigo colgando por los codos y una gorra de béisbol hundida sobre su melena desordenada, el viento matutino le recorría la cara con un susurro helado. "¡El ciclista! ¿Volvemos a hacerlo, papa?" 

Asegurándose que la chaqueta quedara bien anudada alrededor de su torso musculoso, Oscar sonrió ante el recuerdo borroso de niño cuando pedaleaba a la escolta junto al lado de su padre. Ambos partían desde una estación del barrio, hoy algo distante con el paso del tiempo.

El rango de vibraciones del tráfico matutino lo sacó de sus pensamientos. Abría los ojos para encontrar las calles adoquinadas llenas de gente despertando a la ciudad. Caminaba rápido pero sin prisa por la acera, tomando el camino a su bicicleta. Bajando unos cuantos tramos que conducían al parque circundante, siempre un punto de encuentro natural para las mañanas.

Deteniéndose un momento en una esquina marcada junto a viejos amigos y familiares. Mientras sus rodillas se movían en un suave balanceo, dejó vagar sus pensamientos entre el pasado brillante e inconcluso. "¿Qué pasa ahora, Oscar?" Preguntaba la voz de Miguel 'El Mole', siempre con ese mazazo sarcástico pero lleno de amistad.

Aquella frase solía surgir en cada ocasión que encontraban a alguien con quien contar sus aventuras y batallas en bicicleta. Ahora, años después y ya siendo un hombre mayor en la vida del barrio, esa frase cobraba una nueva dimensión. Cómo se había convertido ese pedaleo matutino en algo más allá de la mera competencia o el ejercicio físico.

Sus piernas comenzaron a buscar el rumbo habitual que le llevaba al campus universitario de vuelta. No era una ruta fácil, con las calles empinadas del parque incluyendo un tramo desafiante, pero en los últimos tiempos habían modificado la señalización para evitar accidentes. Ahora todo el trayecto se extendía con mayor seguridad.

Pero también, más tiempo.

Conduciéndolo a una reflexión de cómo había evolucionado esa ruta al paso del tiempo. Donde sus amigos y la gente que ya no veían con tanta frecuencia seguían recorriendo las mismas calles, solo en un ritmo diferente. ¿Cuántas conversaciones habían tenido aquí? Cuántos tratos de camaradería fueron tejidos a través de esas mismo andanzas.

Suspiro profundamente, la brisa matutina le recordando que ya estaba más que listo para su jornada. Arrancó el motor silencioso de la bicicleta, preparado para abordar el día que esperaba en el recorrido final hacia el campus universitario.

Pero justo antes del semáforo que llevaba a las puertas del campus, un carril de tráfico ligero en la bicicleta le dio un amague adicional. Sin premeditarlo, Oscar detuvo su andadura y se permitió darse cuenta.

"¡Aparca ahí!", susurró una voz desde el otro lado del acercamiento que desviaba para el campus universitario.

Oscar Gacha observó a un viejo amigo, Miguel 'El Mole', saliendo de entre la vegetación que tapaba parcialmente el cruce. El paso suave y seguro del hombre hacia él, llevando consigo el aire del pasado, fue algo de lo que Oscar nunca se percató.